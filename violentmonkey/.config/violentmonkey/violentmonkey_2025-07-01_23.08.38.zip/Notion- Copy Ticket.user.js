// ==UserScript==
// @name        Notion: Copy Ticket
// @namespace   Violentmonkey Scripts
// @version     2024-09-03
// @description 7/1/2025, 11:14:33 PM
// @author      You
// @match       https://www.notion.so/*/*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=notion.so
// @grant       none
// ==/UserScript==

"use strict";

function getMarkdownUrl() {
  const ticketTitle = document.querySelector(
    "[data-block-id] > h1.notranslate"
  );
  const ticketUrl = window.location.href.split("?")[0];
  const markdownLink = `[${ticketTitle.innerText}](${ticketUrl})`;
  return markdownLink;
}

function main() {
  const button = document.createElement("button");
  button.innerHTML = "<u>C</u>opy";
  button.accessKey = "c";
  button.onclick = () => {
    navigator.clipboard.writeText(getMarkdownUrl());
  };
  button.style.position = "fixed";
  button.style.zIndex = 1000;
  button.style.top = 0;
  button.style.left = "50%";
  button.style.translate = -50 % 0;

  document.body.insertAdjacentElement("afterbegin", button);
}

main();

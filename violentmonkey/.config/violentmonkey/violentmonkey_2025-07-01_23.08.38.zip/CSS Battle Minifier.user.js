// ==UserScript==
// @name        CSS Battle Minifier
// @namespace   Violentmonkey Scripts
// @version     2024-05-18
// @description 7/1/2025, 11:12:05 PM
// @author      You
// @match       https://cssbattle.dev/play/*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=cssbattle.dev
// @grant       none
// ==/UserScript==

const minify = () => {
  let s = prompt("Enter code to be minified:");
  /* Remove \n followed by \s */
  s = s.replace(/\n\s*/gim, "");
  if (confirm("Remove closing tags?")) {
    s = s.replace(/<\/\w >/gim, "");
  }
  /* Remove extra spaces after : , */
  s = s.replace(/(:|,)\s /g, "$1");
  /* Remove extra spaces before { */
  s = s.replace(/\s ({)/g, "$1");
  /* Remove px from width, height, margin, padding & inset values */
  s = s.replace(
    /(width|height|margin|padding|top|right|bottom|left):(\d )px/gim,
    "$1:$2"
  );
  /* Remove quotes from attributes' values */
  s = s.replace(
    /(\w )=("|')([^"'] )("|')/gim,
    (match, attribute, openQuote, value, closeQuote) =>
      /* if the value contains a space, quotes are needed */
      `${attribute}=${value.includes(" ") ? '"' : ""}${value}${
        value.includes(" ") ? '"' : ""
      }`
  );
  /* Remove ; before } */
  s = s.replace(/;(})/g, "$1");
  /* Remove the last )} */
  s = s.replace(/\)?}$/g, "");
  console.log(s);
  navigator.clipboard
    .writeText(s)
    .then(() => alert("Minified code is copied to clipboard."));
  return s;
};

function main() {
  "use strict";

  const minifyButton = document.createElement("button");
  minifyButton.innerHTML = "<u>M</u>inify";
  minifyButton.accessKey = "m";
  minifyButton.classList.add("button");
  minifyButton.onclick = minify;

  const submitButton = document.querySelector(
    '[data-hint="Don\'t be afraid. You can submit multiple times"]'
  );
  submitButton.insertAdjacentElement("beforebegin", minifyButton);
}

document.body.onload = main;

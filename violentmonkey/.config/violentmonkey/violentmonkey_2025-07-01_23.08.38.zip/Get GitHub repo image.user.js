// ==UserScript==
// @name        Get GitHub repo image
// @namespace   Violentmonkey Scripts
// @version     2024-05-18
// @description 7/1/2025, 11:13:55 PM
// @author      You
// @match       https://github.com/*/*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=github.com
// @grant       none
// ==/UserScript==

function createToastElement(type, message) {
  const toastEmoji = type === "success" ? "✅" : type === "error" ? "❌" : "❓";
  const p = document.createElement("p");
  p.textContent = `${toastEmoji} ${message}`;

  p.style.position = "fixed";
  p.style.left = "50%";
  p.style.top = ".5em";
  p.style.translate = "-50% 0";
  p.style.zIndex = 1e5;

  p.style.border = "1px solid white";
  p.style.borderRadius = ".5em";
  p.style.padding = ".5em .75em";

  p.style.backdropFilter = "blur(5px)";
  p.style.fontSize = "1.15em";
  return p;
}

function injectToast(element) {
  document.body.insertAdjacentElement("afterbegin", element);
  setTimeout(() => {
    element.remove();
  }, 3e3);
}

function toast(type, message) {
  injectToast(createToastElement(type, message));
}

function main() {
  "use strict";

  const url = window.location.href;
  const matches = url.matchAll(
    /^https?:\/\/github.com\/(?<username>[^/]+)\/(?<repo>[^/]+)\/?$/g
  );
  const matchesArray = Array.from(matches);

  if (matchesArray.length) {
    console.debug("Running Tampermonkey");
    const username = matchesArray[0][1];
    const repo = matchesArray[0][2];
    const repoUrl = `https://github.com/${username}/${repo}`
    const badgeUrl = `https://github-readme-stats-astronomer.vercel.app/api/pin/?username=${username}&repo=${repo}&theme=tokyonight`
    // const imageMarkdown = `[${username}/${repo}](https://github.com/${username}/${repo})\n@@html: <a href="https://github.com/${username}/${repo}/"><img src="https://github-readme-stats-astronomer.vercel.app/api/pin/?username=${username}&repo=${repo}&theme=tokyonight" alt="${username}/${repo}"/></a>@@`;
    const imageMarkdown = `[![${username}/${repo}](${badgeUrl})](${repoUrl})`

    // Setting up the button and its container to be injected
    const copyImageMarkdownButton = document.createElement("button");
    copyImageMarkdownButton.innerHTML = "<u>C</u>opy repo image";
    copyImageMarkdownButton.accessKey = "c";
    copyImageMarkdownButton.onclick = () => {
      navigator.clipboard.writeText(imageMarkdown);
      toast("success", "Copied repo image");
    };
    copyImageMarkdownButton.classList.add("btn", "btn-sm");

    const listItemForCopyButton = document.createElement("li");
    listItemForCopyButton.appendChild(copyImageMarkdownButton);

    const buttonContainer = document.querySelector(
      "#repository-details-container"
    );
    const buttonsList = buttonContainer.querySelector("ul");
    buttonsList.insertAdjacentElement("afterbegin", listItemForCopyButton);
  } else {
    console.debug("Not running Tampermonkey");
  }
}

main();

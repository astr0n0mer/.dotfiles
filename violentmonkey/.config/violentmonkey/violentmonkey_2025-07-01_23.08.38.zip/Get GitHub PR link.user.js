// ==UserScript==
// @name        Get GitHub PR link
// @namespace   Violentmonkey Scripts
// @version     2024-05-28
// @description 7/1/2025, 11:13:12 PM
// @author      You
// @match       https://github.com/*/pull/*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=github.com
// @grant       none
// ==/UserScript==

"use strict";

function main() {
  const url = window.location.href;
  const heading = document.querySelector(".gh-header-title").innerText;
  const markdownLink = `[${heading}](${url})`;

  const button = document.createElement("button");
  button.innerHTML = "<u>C</u>opy";
  button.accessKey = "c";
  button.classList.add("btn", "Button--small");
  button.onclick = () => {
    navigator.clipboard.writeText(markdownLink);
  };

  const container = document.querySelector(".gh-header-actions");
  container.insertAdjacentElement("afterbegin", button);
}

main();

// ==UserScript==
// @name        YouTube Video: Copy video URL
// @namespace   Violentmonkey Scripts
// @version     2024-05-24
// @description 7/1/2025, 11:16:05 PM
// @author      You
// @match       https://www.youtube.com/watch?v=*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant       none
// ==/UserScript==

"use strict";

function getVideoTitleAsMarkdown() {
  const videoTitle = document.querySelector(
    "#above-the-fold > #title"
  )?.innerText;
  const videoUrl = new URL(window.location.href);
  const formattedVideoUrl = `${videoUrl.origin}${
    videoUrl.pathname
  }?v=${videoUrl.searchParams.get("v")}`;
  const channelName = document.querySelector("#channel-name")?.innerText;

  const formattedText = `${videoTitle} on [[${channelName}]]\n{{video ${formattedVideoUrl}}}`;
  return formattedText;
}

function main() {
  const copyButton = document.createElement("button");
  copyButton.innerText = "C`opy";
  copyButton.accessKey = "c";
  copyButton.onclick = () =>
    navigator.clipboard.writeText(getVideoTitleAsMarkdown());

  copyButton.style.marginInline = "1em";
  copyButton.style.borderRadius = "2em";
  copyButton.style.padding = ".25em .75em";

  copyButton.style.fontSize = "1.75em";
  copyButton.style.backgroundColor = "#272727";
  copyButton.style.color = "white";

  document
    .querySelector("#owner")
    .insertAdjacentElement("beforeend", copyButton);
}

document.body.onload = () =>
  setTimeout(() => {
    main();
  }, 2e3);

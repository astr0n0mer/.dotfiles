// ==UserScript==
// @name        YouTube Channel: Copy banner
// @namespace   Violentmonkey Scripts
// @version     2024-05-24
// @description 7/1/2025, 11:15:22 PM
// @author      You
// @match       https://www.youtube.com/@*
// @match       https://www.youtube.com/channel/*
// @icon        https://www.google.com/s2/favicons?sz=64&domain=youtube.com
// @grant       none
// ==/UserScript==

"use strict";

function getChannelBannerAsMarkdown() {
  const channelName = document.querySelector(
    ".dynamic-text-view-model-wiz.page-header-view-model-wiz__page-header-title.page-header-view-model-wiz__page-header-title--page-header-title-large"
  )?.textContent;
  const channelHandle = document.querySelector(".yt-content-metadata-view-model-wiz__metadata-row.yt-content-metadata-view-model-wiz__metadata-row--metadata-row-inline")?.textContent;
  const channelBannerImg = document.querySelector("#page-header-banner-sizer img")?.src;

  const formattedText = `![${channelName} on YouTube](${channelBannerImg})\n#[[YouTube/Channel]]\n[YouTube](https://www.youtube.com/${channelHandle})`;
  return formattedText;
}

function main() {
  const subscribeButton = document.querySelector("yt-subscribe-button-view-model");
  const channelBannerAsMarkdown = getChannelBannerAsMarkdown();
  const copyButton = document.createElement("button");
  copyButton.innerText = "C`opy banner";
  copyButton.accessKey = "c";
  copyButton.onclick = () => {
    navigator.clipboard.writeText(channelBannerAsMarkdown);
  };
  copyButton.classList = subscribeButton.classList;
  copyButton.style = subscribeButton.style;
  copyButton.style.borderRadius = "2em";
  copyButton.style.padding = ".5em .75em";

  const buttonContainer = document.querySelector("yt-flexible-actions-view-model");
  buttonContainer.insertAdjacentElement("beforeend", copyButton);
}

document.body.onload = () =>
  setTimeout(() => {
    main();
  }, 2e3);

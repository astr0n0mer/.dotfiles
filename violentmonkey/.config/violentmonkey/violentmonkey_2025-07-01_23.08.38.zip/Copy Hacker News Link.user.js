// ==UserScript==
// @name        Copy Hacker News Link
// @namespace   Violentmonkey Scripts
// @version     1.0
// @description 7/1/2025, 11:09:04 PM
// @author       You
// @match        https://news.ycombinator.com/item?id=*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=ycombinator.com
// @grant        none
// ==/UserScript==

(function() {
	"use strict";

	const titleLine = document.querySelector(".titleline");
	let linkText = titleLine.textContent;
	const linkUrl = window.location.href;
    const charsToEscape = "[]()"

    for(let c of charsToEscape) {
        linkText.replace(c, `\${c}`);
    }
	const markdownUrl = `[${linkText}](${linkUrl})`;

	const logseqTaskText = {
        text: `TODO ${markdownUrl} on [[Hacker News]]`,
        accessKey: "c"
    };
    const vimwikiTaskText = {
        text: `- [ ] [[${linkUrl}|${linkText}]] on :hacker_news:`,
        accessKey: "v"
    };
    const markdownTaskText = {
        text: `- [ ] ${markdownUrl} on [[hacker-news]]\n\n`,
        accessKey: "m"
    };

	[markdownTaskText].forEach((text) => {
		const textAreaMarkdown = document.createElement("textarea");
		textAreaMarkdown.value = text.text;
		textAreaMarkdown.accessKey = text.accessKey;
		textAreaMarkdown.title = "accessKey: " + text.accessKey.toUpperCase();
		textAreaMarkdown.onfocus = () =>
			navigator.clipboard.writeText(textAreaMarkdown.value);
		textAreaMarkdown.style.width = "100%";
		titleLine.insertAdjacentElement("beforeend", textAreaMarkdown);
	});
})();
